package com.wow.rpc.ReusableMethods;



import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.wow.rpc.Reports.WowReport;
import com.wow.rpc.Utils.DataUtilities;
import com.wow.rpc.Utils.GlobalVariables;


public class GurukulaLogin extends GlobalVariables {
	
	
	protected static Logger log = Logger.getLogger(GurukulaLogin.class);
	boolean mstatus = false;
	
 public void rcLogin2(WebDriver webDriver, String environment, WowReport reportThis, DataUtilities envDataload) throws Exception {
	   
 	
 	try {

 		System.out.println("driver==" +webDriver + " environment==" +environment);

 		if (environment.equalsIgnoreCase("MainURL")) {

 			webDriver.get(envDataload.getTestdata("MainURL"));
 			reportThis.CustReport(webDriver,"Login Page", "Navigated to Url : " + envDataload.getTestdata("UATURLV"), "Pass");

 			webDriver.manage().window().maximize();
 			webDriver.findElement(By.xpath("//a[contains(text(),'Register a new account')]")).click();
 			Thread.sleep(3000);
 			WebElement Loginname = webDriver.findElement(By.xpath(envDataload.getObject("LogIn")));
 			Loginname.clear();
 			Loginname.sendKeys(envDataload.getTestdata("NewLoginName"));
 			reportThis.CustReport(webDriver, "Gurukula Login", "Entered UserName", "Pass");
 			
 			
 			WebElement EmailField = webDriver.findElement(By.xpath(envDataload.getObject("Email")));
 			EmailField.clear();
 			EmailField.sendKeys(envDataload.getTestdata("Emailid"));
 			reportThis.CustReport(webDriver, "Gurukula Emailid", "Entered Emailid", "Pass");
 			
 			
 			WebElement PwField = webDriver.findElement(By.xpath(envDataload.getObject("NewPw")));
 			PwField.clear();
 			PwField.sendKeys(envDataload.getTestdata("Pw"));
 			reportThis.CustReport(webDriver, "Gurukula Paswword", "Entered passowrd", "Pass");
 			
 			WebElement ConfPwField = webDriver.findElement(By.xpath(envDataload.getObject("NewPwConf")));
 			ConfPwField.clear();
 			ConfPwField.sendKeys(envDataload.getTestdata("ConfPw"));
 			reportThis.CustReport(webDriver, "Gurukula confirmation Paswword", "Entered confirmation passowrd", "Pass");
 			Thread.sleep(3000);
 			WebElement RegBtnField = webDriver.findElement(By.xpath(envDataload.getObject("RegBtn")));
 			RegBtnField.click();
 			reportThis.CustReport(webDriver, "Gurukula Reg Button", "Clicked Reg Button", "Pass");
 			
 			Thread.sleep(3000);
 			JavascriptExecutor js = (JavascriptExecutor) webDriver;
 			js.executeScript("window.scrollBy(0,1000)");
 			webDriver.findElement(By.xpath("//a[contains(text(),'login')]")).click();
 			Thread.sleep(3000);
 			WebElement username = webDriver.findElement(By.id(envDataload.getObject("uname")));
 			username.clear();
 			username.sendKeys(envDataload.getTestdata("UserName"));
 			reportThis.CustReport(webDriver, "Gurukula Login", "Entered UserName", "Pass");

 			
 			webDriver.findElement(By.id(envDataload.getObject("pass"))).sendKeys(envDataload.getTestdata("PassWord"));
 			reportThis.CustReport(webDriver,"Gurukula Login", "Entered Password", "Pass");

 		} 
 		

 		Thread.sleep(3000);
        webDriver.findElement(By.xpath("//button[@class='btn btn-primary ng-scope']")).click();
 		Thread.sleep(2000);
 		reportThis.CustReport(webDriver,"Gurukula Login ", "Clicked on login button ", "Pass_ScreenShot");

 	}

 	catch (Exception e) {
 		e.printStackTrace();
 		reportThis.CustReport(webDriver,"Gurukula Login ", "Username/Password is incorrect.Login failed", "Fail");
 	}

 
 }

	
     
 }
