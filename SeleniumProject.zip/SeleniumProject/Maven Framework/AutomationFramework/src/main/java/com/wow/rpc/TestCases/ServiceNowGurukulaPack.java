package com.wow.rpc.TestCases;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;
import org.testng.log4testng.Logger;

import com.wow.rpc.Reports.WowReport;
import com.wow.rpc.ReusableMethods.GenericMethods;
import com.wow.rpc.ReusableMethods.TestBase;
import com.wow.rpc.ReusableMethods.GurukulaLogin;
import com.wow.rpc.Utils.DataUtilities;
//import com.wow.rpc.pages.DemandForcastScreenPage;
import com.wow.rpc.pages.GurukulaContainerPack;

public class ServiceNowGurukulaPack extends TestBase {
	
	Logger log = org.testng.log4testng.Logger.getLogger(ServiceNowGurukulaPack.class);
	
	


	@Test
	public void Gurukula_TC01_ValidateE2EGurukulaApplication() throws Exception {

		String pageTitle = "Verify the E2E functionality of Gurukula application";
		 			
		 long startTime;

		 long endTime;

		 long differenceTime;

		 long differenceTimeSecs;
		
		 long differenceTimeMin;
		
		 String duration;
		
				startTime = System.currentTimeMillis();
				GurukulaLogin wowObj =  new GurukulaLogin();
				DataUtilities envDataload = new DataUtilities();
				WowReport reportThis =  new WowReport();
				GenericMethods reObject  =  new GenericMethods();
				String curExeMethodName = Thread.currentThread().getStackTrace()[1].getMethodName();
				String environment = getEnvironment();
				String browserName = getBrowserName();
				String testSetname = getTestSetName();
			try {
				
				reportThis.createReport(curExeMethodName, browserName, testSetname);
			    envDataload.loadEnvProperties();
			    envDataload.loadObjRepositories();
			    envDataload.loadTestScripts(curExeMethodName,environment);
			    wowObj.rcLogin2(getDriver(),environment,reportThis,envDataload);
			    reObject.waitForPageLoad(getDriver());
			    GurukulaContainerPack vpxpagp = new GurukulaContainerPack(getDriver(), pageTitle, reportThis);
			    vpxpagp.navigateToBranch(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.CreateNewBranch(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionView(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionViewEdit(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionQuery(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.navigateToStaff(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.CreateNewStaff(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionViewStaff(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionViewEdit(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionQuery(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionDelete(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.navigateToBranch(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.ActionDelete(getDriver(), reportThis, envDataload, reObject);
			    vpxpagp.rclogout(getDriver(), reportThis, envDataload, reObject);
				
				}
		catch(Exception e) { 
			e.printStackTrace();
			reportThis.CustReport(getDriver(),pageTitle, pageTitle + " Execution interrupted by Some issues", "Fail");
            
		}
		finally {
			
			reportThis.CustReportclose(false, "");
			reportThis.overAllFooter();
			endTime = System.currentTimeMillis();
			differenceTime = endTime - startTime;
			differenceTimeSecs = TimeUnit.MILLISECONDS.toSeconds(differenceTime);
			differenceTimeMin = differenceTimeSecs / 60;
			log.info("Diff of time in min" + differenceTimeMin);
			duration = String.valueOf(differenceTimeMin);
			String exeStatus =  reportThis.getOvellAllReportStatus();
			String testName = envDataload.getTestdata("TestCaseDesc");
			reportThis.overallStatusReport(testName, duration,exeStatus , browserName, environment);
		}
	}
}