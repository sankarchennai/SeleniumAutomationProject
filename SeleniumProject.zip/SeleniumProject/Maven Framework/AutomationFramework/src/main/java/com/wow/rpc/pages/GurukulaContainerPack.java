package com.wow.rpc.pages;

import java.awt.AWTException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.List;

import org.jsoup.select.Evaluator.IsEmpty;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.wow.rpc.Reports.WowReport;
import com.wow.rpc.ReusableMethods.GenericMethods;
import com.wow.rpc.ReusableMethods.TestBase;
import com.wow.rpc.Utils.DataUtilities;


public class GurukulaContainerPack  extends TestBase {

	private static final String NewBranchName = null;
	GenericMethods objGenericMethods = new GenericMethods();
	WebDriver webdriver;
	String pageTitle ;
	WowReport reportThis; 


    //Declaring web elements for entities menu and sub menu 
	
	
		@FindBy(xpath="//span[contains(text(),'Entities')]")
		private WebElement EntitiesMenu;
		
		@FindBy(xpath="//span[contains(text(),'Branch')]")
		private WebElement Branch;
		
		@FindBy(xpath="//span[contains(text(),'Staff')]")
		private WebElement Staff;
		
		@FindBy(xpath="//span[contains(text(),'Create a new Staff')]")
		private WebElement NewStaffBtn;
		
	//Declaring Web Elements for New Branch
		
		@FindBy(xpath="//span[contains(text(),'Create a new Branch')]")
		private WebElement NewBranchButton;
		
		@FindBy(xpath="//form/div/div[2]/input[@name='name'][1]")
		private WebElement BranchNameField;
	    
		
		@FindBy(xpath="//form/div/div[2]/input[@name='name']")
		private WebElement StaffNameField;
		
		@FindBy(xpath="//*[@name='code']")
		private WebElement BranchCode;
		
		@FindBy(xpath="//select[@name='related_branch']")
		private WebElement BranchNameDrpdown;
		
		
		@FindBy(xpath="//span[contains(text(),'Save')]")
		private WebElement BranchSaveButton;
		
		@FindBy(xpath="//span[contains(text(),'View')]")
		private WebElement ActionViewBtn;
		
		@FindBy(xpath="//button[@class='btn btn-info btn-sm']")
		private WebElement ActionBrachViewBtn;
		
		@FindBy(xpath="//span[contains(text(),'Edit')]")
		private WebElement ActionEditBtn;
		
		@FindBy(xpath="//button[@class='btn btn-danger btn-sm']")
		private WebElement ActionDeleteBtn;
		
		@FindBy(xpath="//button[@class='btn btn-danger']")
		private WebElement ActionDeletePopupBtn;
		
		
		@FindBy(xpath="//button[@class='btn btn-info']")
		private WebElement ActionBackBtn;
		
		@FindBy(xpath="//input[@id='searchQuery']")
		private WebElement QueryTextField;
		
		@FindBy(xpath="//button[@class='btn btn-info']")
		private WebElement QueryBtn;
		
		
		@FindBy(xpath="//*[@class='table table-striped']/tbody/tr[1]/td[2]")
		private WebElement BrWebTable;
		
		@FindBy(xpath="//span[contains(text(),'Account')]")
		private WebElement AccountMenu;
		
		@FindBy(xpath="//span[contains(text(),'Log out')]")
		private WebElement LogoutBtn;

public GurukulaContainerPack(WebDriver driverPassed , String pageTitlePassed, WowReport reportThisPassed) {
	this.webdriver = driverPassed;
	this.pageTitle = pageTitlePassed;
	this.reportThis = reportThisPassed;
	PageFactory.initElements(webdriver, this);
}




public void navigateToBranch(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)  {
		
	try {
		
Thread.sleep(3000);

reObject.viewToELement(getDriver(),reportThis,EntitiesMenu  );
reportThis.CustReport(getDriver(), pageTitle, "Navigated to Entities Menu", "Pass" );
reObject.inputForSendKeysAndClick(getDriver(),reportThis,EntitiesMenu,"","click" );
Thread.sleep(2000);
reportThis.CustReport(getDriver(), pageTitle, "Clicked on EntitiesMenu", "Pass" );
reObject.viewToELement(getDriver(),reportThis,Branch  );
reportThis.CustReport(getDriver(), pageTitle, "Navigated to Branch", "Pass" );
reObject.inputForSendKeysAndClick(getDriver(),reportThis,Branch,"","click" );
Thread.sleep(2000);
reportThis.CustReport(getDriver(), pageTitle, "Clicked on Branch Menu", "Pass" );

	}
	catch(Exception e) {
		e.printStackTrace();
		reportThis.CustReport(getDriver(),pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}
}

public void navigateToStaff(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)  {
	
	try {
		
Thread.sleep(3000);

reObject.viewToELement(getDriver(),reportThis,EntitiesMenu  );
reportThis.CustReport(getDriver(), pageTitle, "Navigated to Entities Menu", "Pass" );
reObject.inputForSendKeysAndClick(getDriver(),reportThis,EntitiesMenu,"","click" );
Thread.sleep(2000);
reportThis.CustReport(getDriver(), pageTitle, "Clicked on EntitiesMenu", "Pass" );
reObject.viewToELement(getDriver(),reportThis,Staff);
reportThis.CustReport(getDriver(), pageTitle, "Navigated to Staff", "Pass" );
reObject.inputForSendKeysAndClick(getDriver(),reportThis,Staff,"","click" );
Thread.sleep(3000);
reportThis.CustReport(getDriver(), pageTitle, "Clicked on Staff Menu", "Pass" );

	}
	catch(Exception e) {
		e.printStackTrace();
		reportThis.CustReport(getDriver(),pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}
}

public void CreateNewStaff(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   {
		
	try {
Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,NewStaffBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to New Staff screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,NewStaffBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on New Staff  button", "Pass" );

Thread.sleep(3000);

	
reObject.viewToELement(driver,reportThis,StaffNameField);
reObject.inputForSendKeysAndClick(driver,reportThis,StaffNameField,envDataload.getTestdata("StaffName"),"input");
reportThis.CustReport(driver, pageTitle, "Input has been keyed in successfully for Staff Name", "Pass");
Thread.sleep(3000);
reObject.selectDropDownText(driver, reportThis, BranchNameDrpdown, envDataload.getTestdata("EditNameBranch"),"ByText");
reportThis.CustReport(driver, pageTitle, "Branch dropdown selected successfully", "Pass");

Thread.sleep(3000);
reObject.inputForSendKeysAndClick(driver,reportThis,BranchSaveButton,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Branch Save button", "Pass" );
reObject.viewToELement(driver,reportThis,BranchSaveButton  );


	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}



public void CreateNewBranch(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   {
	
	try {
Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,NewBranchButton  );
reportThis.CustReport(driver, pageTitle, "Navigated to NewBranchButton screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,NewBranchButton,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on New Branch  button", "Pass" );

Thread.sleep(5000);

	
reObject.viewToELement(driver,reportThis,BranchNameField);
reObject.inputForSendKeysAndClick(driver,reportThis,BranchNameField,envDataload.getTestdata("NameBranch"),"input");
reportThis.CustReport(driver, pageTitle, "Input has been keyed in successfully for BranchName", "Pass");

reObject.viewToELement(driver,reportThis,BranchCode);
reObject.inputForSendKeysAndClick(driver,reportThis,BranchCode,envDataload.getTestdata("Code"),"input");
reportThis.CustReport(driver, pageTitle, "Input has been keyed in successfully for Staff Name", "Pass");


reObject.inputForSendKeysAndClick(driver,reportThis,BranchSaveButton,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Branch Save button", "Pass" );
reObject.viewToELement(driver,reportThis,BranchSaveButton  );


	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}




public void ActionView(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   
{
	
	try {
		Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,ActionBrachViewBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to View screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionBrachViewBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on View  button", "Pass" );

Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,ActionBackBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to Main screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionBackBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Back button", "Pass" );

Thread.sleep(3000);

String text = reObject.getText(driver, reportThis,BrWebTable).trim();
if(text.equals(envDataload.getTestdata("NameBranch")))
{
reportThis.CustReport(driver, pageTitle, "New Branch screen is disPlayed and verified", "Pass_ScreenShot");
}
else {
reportThis.CustReport(driver, pageTitle, "New Branch screen is not disPlayed as expected", "Fail");
        }
	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}


public void ActionViewEdit(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   
{
		
	try {
		Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,ActionEditBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to Edit screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionEditBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Edit button", "Pass" );

Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,BranchNameField);
reObject.inputForSendKeysAndClick(driver,reportThis,BranchNameField,envDataload.getTestdata("EditNameBranch"),"input");
reportThis.CustReport(driver, pageTitle, "Input has been keyed in successfully for BranchName", "Pass");
Thread.sleep(3000);
reObject.inputForSendKeysAndClick(driver,reportThis,BranchSaveButton,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Branch Save button", "Pass" );
reObject.viewToELement(driver,reportThis,BranchSaveButton);
Thread.sleep(3000);
String text = reObject.getText(driver, reportThis,BrWebTable).trim();
if(text.equals(envDataload.getTestdata("EditNameBranch")))
{
reportThis.CustReport(driver, pageTitle, "New Edited Branch screen is disPlayed and verified", "Pass_ScreenShot");
}
else {
reportThis.CustReport(driver, pageTitle, "New Edited Branch screen is not disPlayed as expected", "Fail");
        }
	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}



public void ActionQuery(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   
{
		
	try {
		
Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,QueryTextField);
reObject.inputForSendKeysAndClick(driver,reportThis,QueryTextField,envDataload.getTestdata("Query"),"input");
reportThis.CustReport(driver, pageTitle, "Input has been keyed in successfully for query", "Pass");
Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,QueryBtn);
reObject.inputForSendKeysAndClick(driver,reportThis,QueryBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on query button", "Pass" );

Thread.sleep(3000);
String text = reObject.getText(driver, reportThis,BrWebTable).trim();
if(text.equals(envDataload.getTestdata("Query")))
{
reportThis.CustReport(driver, pageTitle, "New Branch screen is disPlayed and verified", "Pass_ScreenShot");
}
else {
reportThis.CustReport(driver, pageTitle, "New Branch screen is not disPlayed as expected", "Fail");
        }
	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}

public void ActionViewStaff(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   
{
	
	try {
		Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,ActionViewBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to View screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionViewBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on View  button", "Pass" );

Thread.sleep(5000);
reObject.viewToELement(driver,reportThis,ActionBackBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to Main screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionBackBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Back button", "Pass" );

Thread.sleep(5000);

String text = reObject.getText(driver, reportThis,BrWebTable).trim();
if(text.equals(envDataload.getTestdata("StaffName")))
{
reportThis.CustReport(driver, pageTitle, "New Staff screen is disPlayed and verified", "Pass_ScreenShot");
}
else {
reportThis.CustReport(driver, pageTitle, "New Staff screen is not disPlayed as expected", "Fail");
        }
	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}

public void ActionDelete(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   
{
		
	try {
		Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,ActionDeleteBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to Delete screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionDeleteBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Delete button", "Pass" );
Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,ActionDeletePopupBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to Delete popup screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,ActionDeletePopupBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Delete button", "Pass" );

	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}

public void rclogout(WebDriver driver,WowReport reportThis, DataUtilities envDataload, GenericMethods reObject)   
{
		
	try {
		Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,AccountMenu);
reportThis.CustReport(driver, pageTitle, "Navigated to Account menu screen", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,AccountMenu,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Account Menu button", "Pass" );
Thread.sleep(3000);
reObject.viewToELement(driver,reportThis,LogoutBtn);
reportThis.CustReport(driver, pageTitle, "Navigated to LogoutBtn", "Pass" );
reObject.inputForSendKeysAndClick(driver,reportThis,LogoutBtn,"","click" );
reportThis.CustReport(driver, pageTitle, "Clicked on Log out button", "Pass" );

	}
	catch(Exception e) {
		
		reportThis.CustReport(driver,pageTitle, pageTitle + "   interrupted by Some issues", "Fail");
		
	}

}
}