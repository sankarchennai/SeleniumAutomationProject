package com.wow.rpc.ReusableMethods;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.UnexpectedException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.log4testng.Logger;
import com.wow.rpc.Reports.WowReport;


public class TestBase {


	public static ThreadLocal<RemoteWebDriver> webDriver = new ThreadLocal<RemoteWebDriver>();
	protected Logger log = org.testng.log4testng.Logger.getLogger(TestBase.class);
    private String browserName;
    private String environment;
    private String testSetName;
  
    public WebDriver getDriver() {
        return webDriver.get();
    }

    @BeforeSuite
   	public void beforeSuite() {
   		log.info("Inside @BeforeSuite");
   		deleteFiles();
   		
   	}
 
    @Parameters({ "browser", "ENV" })
	@BeforeTest
	public void beforeTest(String browser, String ENV, ITestContext testContext) {
		log.info("Inside @BeforeTest");
		this.browserName = browser;
		this.environment = ENV;
		this.testSetName = testContext.getName();

    }
    
    @BeforeMethod
    protected void createDriver()
            throws MalformedURLException, UnexpectedException {
      
        if(browserName.equalsIgnoreCase("GRID")) { 
        	
        
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(CapabilityType.TAKES_SCREENSHOT, true);
		capabilities.setJavascriptEnabled(true);
        } else if(browserName.equalsIgnoreCase("CH")) { 

    	String chDriverPath = System.getProperty("user.dir") + "\\src\\test\\resources\\retailsDrivers\\chromedriver.exe";
        System.setProperty("webdriver.chrome.driver", chDriverPath);
		ChromeOptions options = new ChromeOptions();
        options.addArguments("disable-infobars");
        webDriver.set(new ChromeDriver(options));
        
        } else {
        	
        	System.out.println("Browser object not instantiated ..!!");
        	
        }

    }

   
    @AfterMethod
    public void tearDown() throws Exception {
    	
    	try {
	
    		getDriver().quit();

		} catch (Exception e) {
			e.printStackTrace();
		}
        
    }

    @AfterSuite
    
    public void publishReport() throws Exception {
        	WowReport reportThis =  new WowReport();	
        	try {
    	int passTC,failTC;
    	passTC = reportThis.getPassCount();
    	failTC = reportThis.getFailCount();
    	System.out.println("passTC==" +passTC + "failTC " + failTC);
        		 //Mail ma =  new Mail();
        		 
               //  ma.MailScheduler(passTC,failTC);

    		} catch (Exception e) {
    			e.printStackTrace();
    		}
            
        }


	public String getBrowserName() {
		return browserName;
	}
	
	public String getEnvironment(){
		return environment;
	}
	
	public String getTestSetName(){
		return testSetName;
	}
	public void deleteFiles(){
		
		 try {
	        	        
	         File fl = new File((new StringBuilder(String.valueOf(System.getProperty("user.dir")))).append("\\CustReport").toString());
	         if(!fl.exists()) // checking if directory exists
	         {
	            System.out.println("Sorry!! directory doesn't exist.");
	         }
	         else
	         {
	           deleteDirectory(fl);
	         }
	         
	       

	         //file1.delete();
	 } catch (Exception exception) {
	         exception.printStackTrace();
	 }
		
		
		
	}
	public static void deleteDirectory(File file) throws IOException
	{
	   if(file.isDirectory())
	   {
	      if(file.list().length == 0)
	      { 
	         deleteEmptyDirectory(file); 
	      }
	      else
	      {
	         File fe[] = file.listFiles();
	         for(File deleteFile : fe)
	         {
	            deleteDirectory(deleteFile); 
	         }
	         if(file.list().length == 0)
	         {
	            deleteEmptyDirectory(file);
	         }
	      }
	   }
	   else
	   {
	      file.delete();
	  
	   }
	}

	private static void deleteEmptyDirectory(File fi)
	{
	   fi.delete();
	 
	}
	         


    
}
